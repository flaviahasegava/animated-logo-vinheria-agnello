// Importa a biblioteca para o Display LCD 16x2 I2C - Reconhece novos comandos
#include <LiquidCrystal_I2C.h>

// Endereço do LCD I2C (0x27) - Saber qual dispositivo enviar os dados
LiquidCrystal_I2C lcd(0x27, 16, 2);

// Configuração Inicial
void setup() {
  lcd.init();      // Inicialização do LCD
  lcd.backlight(); // Liga a luz de fundo
  lcd.clear();     // Limpa a tela
}

// Frame 1 - Desenho
void frame1() { 
  lcd.clear();

  byte image01[8] = { // Guarda na memória o nome da imagem e as informações das posições em cada pixel criada em 8 linhas de altura
    B00000, B11111, B11111, B01110, B00100, B00100, B00100, B01110 // Desenho em bytes (B sendo bytes)
  };

  lcd.createChar(0, image01); // Cria/Salva o desenho (nome da imagem) na memória do LCD
  lcd.setCursor(7, 0); // Posiciona o cursor na coluna 7(8) e linha 0(1) no display
  lcd.write(byte(0)); // Desenha na tela o símbolo salvo na posição 0 da memória
}

// Frame 2
void frame2() {
  lcd.clear();

  byte image01[8] = {
    B00000, B00000, B11000, B00100, B01111, B11100, B11000, B00000
  };
  byte image02[8] = {
    B00000, B00000, B00000, B01000, B11000, B01000, B00000, B00000
  };
  byte image03[8] = {
    B00000, B00000, B00000, B00000, B00000, B00000, B00000, B00001
  };
  byte image04[8] = {
    B00011, B00010, B00000, B00010, B00000, B00000, B00000, B00000
  };

  lcd.createChar(0, image01);
  lcd.createChar(1, image02);
  lcd.createChar(2, image03);
  lcd.createChar(3, image04);

  lcd.setCursor(7, 0); lcd.write(byte(0));
  lcd.setCursor(8, 0); lcd.write(byte(1));
  lcd.setCursor(6, 0); lcd.write(byte(2));
  lcd.setCursor(6, 1); lcd.write(byte(3));
}

// Frame 3
void frame3() {
  lcd.clear();

  byte image01[8] = {
    B00000, B00000, B11000, B00100, B00011, B00100, B11000, B00000
  };
  byte image02[8] = {
    B00000, B00000, B00000, B01000, B11000, B01000, B00000, B00000
  };
  byte image03[8] = {
    B00000, B00000, B00000, B00000, B00000, B00000, B00000, B00001
  };
  byte image04[8] = {
    B00001, B00011, B00011, B00110, B00010, B00000, B00010, B00000
  };

  lcd.createChar(0, image01);
  lcd.createChar(1, image02);
  lcd.createChar(2, image03);
  lcd.createChar(3, image04);

  lcd.setCursor(7, 0); lcd.write(byte(0));
  lcd.setCursor(8, 0); lcd.write(byte(1));
  lcd.setCursor(6, 0); lcd.write(byte(2));
  lcd.setCursor(6, 1); lcd.write(byte(3));
}

// Frame 4
void frame4() {
  lcd.clear();

  byte image01[8] = {
    B00000, B00001, B00000, B00001, B00010, B00001, B00011, B00110
  };
  byte image2[8] = {
    B00010, B00000, B00000, B00000, B00000, B00000, B00000, B00000
  };

  lcd.createChar(0, image01);
  lcd.createChar(1, image2);

  lcd.setCursor(6, 0); lcd.write(byte(0));
  lcd.setCursor(6, 1); lcd.write(byte(1));
}

// Frame 5
void frame5() {
  lcd.clear();

  byte image01[8] = {
    B00010, B00100, B00100, B01100, B11000, B01001, B11011, B01110
  };
  byte image02[8] = {
    B00000, B00000, B00000, B10100, B11000, B10000, B10000, B00000
  };

  lcd.createChar(0, image01);
  lcd.createChar(1, image02);

  lcd.setCursor(6, 0); lcd.write(byte(0));
  lcd.setCursor(7, 0); lcd.write(byte(1));
}

// Frame 6
void frame6() {
  lcd.clear();

  byte image01[8] = {
    B00010, B00100, B00100, B01100, B11000, B01001, B11011, B01110
  };
  byte image02[8] = {
    B00000, B00000, B00000, B10110, B11001, B10000, B10000, B10000
  };
  byte image03[8] = {
    B00000, B00000, B00000, B01110, B10001, B01111, B11001, B01111
  };
  byte image4[8] = {
    B00001, B10001, B01110, B00000, B00000, B00000, B00000, B00000
  };

  lcd.createChar(0, image01);
  lcd.createChar(1, image02);
  lcd.createChar(2, image03);
  lcd.createChar(3, image4);

  lcd.setCursor(6, 0); lcd.write(byte(0));
  lcd.setCursor(7, 0); lcd.write(byte(1));
  lcd.setCursor(8, 0); lcd.write(byte(2));
  lcd.setCursor(6, 1); lcd.write(byte(3));
}

// Frame 7
void frame7() {
  lcd.clear();

  byte image01[8] = {
    B00000, B00000, B00000, B01110, B11001, B01101, B11111, B01110
  };
  byte image02[8] = {
    B00000, B00000, B00000, B10110, B11001, B10000, B10000, B10000
  };
  byte image03[8] = {
    B00000, B00000, B00000, B01110, B10001, B01111, B11001, B01111
  };
  byte image04[8] = {
    B00001, B10001, B01110, B00000, B00000, B00000, B00000, B00000
  };
  byte image05[8] = {
    B00000, B00000, B00000, B10110, B11001, B10001, B11110, B10000
  };
  byte image06[8] = {
    B10000, B10000, B10000, B00000, B00000, B00000, B00000, B00000
  };
  byte image07[8] = {
    B00000, B00000, B00000, B01110, B10001, B11111, B10000, B01111
  };

  lcd.createChar(0, image01);
  lcd.createChar(1, image02);
  lcd.createChar(2, image03);
  lcd.createChar(3, image04);
  lcd.createChar(4, image05);
  lcd.createChar(5, image06);
  lcd.createChar(6, image07);

  lcd.setCursor(6, 0); lcd.write(byte(0));
  lcd.setCursor(7, 0); lcd.write(byte(1));
  lcd.setCursor(8, 0); lcd.write(byte(2));
  lcd.setCursor(6, 1); lcd.write(byte(3));
  lcd.setCursor(9, 0); lcd.write(byte(4));
  lcd.setCursor(9, 1); lcd.write(byte(5));
  lcd.setCursor(10, 0); lcd.write(byte(6));
}

// Função para começar um loop da imagem
void loop() {
  // Mostra a imagem do frame 1
  frame1();
  // Espera um tempo para o próximo frame
  delay(800);

  frame2();
  delay(600);

  frame3();
  delay(500);

  frame4();
  delay(700);

  frame5();
  delay(400);

  frame6();
  delay(400);

  frame7();
  delay(1350);

  lcd.clear();

  lcd.setCursor(0, 0);    
  lcd.print("Bem-vindo(a) a"); // Mostra a mensagem em texto na tela do LCD

  lcd.setCursor(0, 1); 
  lcd.print("Adega Agnello!"); 
  delay(1000);
  
  // Repete o comando abaixo dele 16 vezes da mensagem em texto (0 até 15)
  for(int x = 0; x < 16; x++) { 
    lcd.scrollDisplayRight(); // Move todo o texto 1 coluna para a direita
    delay(400);
  }

  // Limpa a tela para recomeçar o loop da imagem e espera um tempo antes de começar
  lcd.clear(); 
  delay(500);
}
